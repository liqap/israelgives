# import libs
import requests
import zipfile
import os
import eel
from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import webbrowser

@eel.expose
def save_us(link):
	try:
		filenameUS = 'us.zip'
		r = requests.get(link, allow_redirects=True)
		open(filenameUS, "wb").write(r.content)
		archiveUS = zipfile.ZipFile('us.zip', 'r')
		archiveUS.extractall('.')
		archiveUS.close()
		os.remove('us.zip')
		os.rename('data-download-pub78.txt', 'us.txt')
	except:
		print('There is an Error, sorry, try again later!')

@eel.expose
def save_uk(link):
	try:
		filenameUK = 'uk.zip'
		s = requests.get(link, allow_redirects=True)
		open(filenameUK, "wb").write(s.content)
		archiveUK = zipfile.ZipFile('uk.zip', 'r')
		archiveUK.extractall('.')
		archiveUK.close()
		os.remove('uk.zip')
		os.rename('publicextract.charity.txt', 'uk.txt')
	except:
		print('There is an Error, sorry, try again later!')


@eel.expose
def save_ca(link):
	linkCanada = 'https://apps.cra-arc.gc.ca/ebci/hacc/srch/pub/advncdSrch'
	#driver = webdriver.Chrome('/Users/neo/chromedriver')
	driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
	driver.get(linkCanada)
	
	form = driver.find_element(By.ID, 'dwnldZp')
	buttonDwnld = form.find_element(By.CLASS_NAME, 'btn')

	if buttonDwnld != None:
		print('Found')
		buttonDwnld.click()
		print('Succes')
	else:
		print('Not found')


@eel.expose
def save_il(link):

	dls = link
	resp = requests.get(dls)
	output = open('il.xlsx', 'wb')
	output.write(resp.content)
	output.close()
	xl = pd.ExcelFile('il.xlsx')
	
	for sheet in xl.sheet_names:
		file = pd.read_excel(xl, sheet_name=sheet)
		file.to_csv(sheet+'.txt', header=False, index=False)



@eel.expose
def merging():
	os.rename('דוח חודשי יוני 2022.txt', 'il.txt')
	os.remove('הסתייגויות והבהרות.txt')
	os.remove('il.xlsx')
	open("final.txt","w").write(open("us.txt","r").read() + open("uk.txt","r").read() + open("il.txt","r").read())
	webbrowser.open('final.txt')






linkUS = 'https://apps.irs.gov/pub/epostcard/data-download-pub78.zip'
linkUK = 'https://ccewuksprdoneregsadata1.blob.core.windows.net/data/txt/publicextract.charity.zip'
linkCA = 'https://apps.cra-arc.gc.ca/ebci/hacc/srch/pub/advncdSrch'
linkIL = 'https://www.guidestar.org.il/sfc/servlet.shepherd/document/download/0690800000GqK2KAAV'
# 	חודשי גיידסטאר מאי



eel.init("web")
eel.start("main.html", size = (900, 500))